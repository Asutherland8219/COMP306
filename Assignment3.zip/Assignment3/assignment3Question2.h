//
// Created by asuth on 10/31/2023.
//

#ifndef COMP306_ASSIGNMENT3QUESTION2_H
#define COMP306_ASSIGNMENT3QUESTION2_H

#include <iostream>
#include <fstream>

void printLineByLine(std::ifstream& inputFile);

#endif //COMP306_ASSIGNMENT3QUESTION2_H

