//
// Created by asuth on 11/1/2023.
//

#ifndef COMP306_CHECKTYPE_H
#define COMP306_CHECKTYPE_H

#include <iostream>

bool checkType(std::string fileName);

#endif //COMP306_CHECKTYPE_H
